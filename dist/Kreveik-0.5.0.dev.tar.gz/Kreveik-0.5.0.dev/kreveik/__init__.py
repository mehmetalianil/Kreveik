import numpy as num
import matplotlib.pyplot as plt
import scorers
import probes
import copy
import boolfuncs

from classes import *
# So that widely used class defs like Network, Family can be used
# without much fuss like classes.Network


__author__ = "Mehmet Ali Anil"
__copyright__ = ""
__credits__ = ["Mehmet Ali Anil"]
__license__ = ""
__version__ = "0.5.0 dev"
__maintainer__ = "Mehmet Ali Anil"
__email__ = "mehmet.ali.anil@ieee.org"
__status__ = "Production"
    
    

