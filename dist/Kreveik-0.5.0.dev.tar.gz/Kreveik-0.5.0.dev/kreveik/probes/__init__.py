"""
Probes are objects that are meant to calculate and accumulate data from the
subroutines of the  simulation.
"""

from probes import *
